<?php
/**
 * 推送评论通知 支持Qmsg酱推送模式
 * 
 * @package CommentPush
 * @author max
 * @version 1.0
 * @link https://www.maxtral.fun
 */
class CommentPush_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Feedback')->comment = array('CommentPush_Plugin', 'sc_send');
        Typecho_Plugin::factory('Widget_Feedback')->trackback = array('CommentPush_Plugin', 'sc_send');
        Typecho_Plugin::factory('Widget_XmlRpc')->pingback = array('CommentPush_Plugin', 'sc_send');
        
        return _t('请配置此插件的 KEY 和 QQ号码, 以使您的Qmsg酱推送生效');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){}
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $key = new Typecho_Widget_Helper_Form_Element_Text('sckey', NULL, NULL, _t('KEY'), _t('请填写您的Qmsg酱 API Key'));
        $form->addInput($key->addRule('required', _t('您必须填写一个正确的 Qmsg 酱 API Key')));

        $qq = new Typecho_Widget_Helper_Form_Element_Text('chatid', NULL, NULL, _t('接收QQ号码'), _t('填写接收推送消息的QQ号码'));
        $form->addInput($qq);

        $element = new Typecho_Widget_Helper_Form_Element_Radio('show', array(0 => '不显示', 1 => '显示'), 0, _t('推送是否显示评论内容和昵称(防止推送色情 暴力 政治敏感评论)'));
        $form->addInput($element);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * Qmsg酱推送
     * 
     * @access public
     * @param array $comment 评论结构
     * @param Typecho_Widget $post 被评论的文章
     * @return void
     */
    public static function sc_send($comment, $post)
    {
        $options = Typecho_Widget::widget('Widget_Options');

        // 获取插件配置中的key和接收QQ号
        $key = $options->plugin('CommentPush')->sckey;
        $qq = $options->plugin('CommentPush')->chatid; // 将chatid用于存储接收QQ号

        // 创建消息内容
        if (Helper::options()->plugin('CommentPush')->show == 1) {
            $msg = "评论者 **".$comment['author']."** 在文章 **".$post->title."** 中发送了评论:\n > ".$comment['text'];
        } else {
            $strlen = mb_strlen($comment['author'], 'utf-8');
            $firstStr = mb_substr($comment['author'], 0, 1, 'utf-8');
            $lastStr = mb_substr($comment['author'], -1, 1, 'utf-8');
            $user_name = $strlen == 2 ? $firstStr . str_repeat('*', mb_strlen($comment['author'], 'utf-8') - 1) : $firstStr . str_repeat("*", $strlen - 2) . $lastStr;

            $msg = "评论者 **".$user_name."** 在文章 **".$post->title."** 中发送了评论";
        }

        // 将数据传递给Qmsg酱的接口
        $postdata = http_build_query(
            array(
                'msg' => $msg,  // 设置发送的消息内容
                'qq' => $qq     // 接收消息的QQ号码
            )
        );

        // 发送请求到Qmsg酱
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://qmsg.zendee.cn/send/'.$key); // Qmsg酱的接口地址
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        return $comment;
    }
}
