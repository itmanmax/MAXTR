# CommentPush

> Typecho 插件——评论推送通知


## 支持的推送模式
本插件的推送采用了
[Server酱](https://sct.ftqq.com/)
**telegram bot API**

## 使用方法

https://www.heinu.cc/archives/77
